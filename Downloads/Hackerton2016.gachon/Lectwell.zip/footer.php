<div id="footer">
	<span>COPYRIGHT © LECTWELL. ALL RIGHTS RESERVED</span>
</div>

