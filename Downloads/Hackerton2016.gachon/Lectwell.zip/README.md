# README #

가천대 강의 추천 서비스 Lectwell

### 폴더구성###

- lecture

  - 강의 추천에 대한 전반적인 기능
  - index / edit

  ​

- member

  - 회원에 대한 기능
  - mypage / delete / edit

  ​

- assets

  - (BACK) CSS/JS

  ​

- file

  - (BACK) 모든 기능적 파일 분류

  ​

- oauth

  - (BACK) 로그인 처리 (signin/up/signin/signup/delete)

  ​


- nodejs 

  - 강의 추천에 대한 기능 담당하는 nodejs server

    ​



---

#### System Overview

- AWS 사용.


- 웹 구현은 Apache 기능, 구현은 Nodejs 



#### NODEJS

#### 	Decision Tree for NodeJS

#### 	https://www.npmjs.com/package/decision-tree

